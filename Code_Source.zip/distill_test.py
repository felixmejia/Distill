import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image
import pandas as pd
import os
import timm # PyTorch Image Models library
from tqdm import tqdm
from sklearn.metrics import roc_auc_score
import numpy as np
import warnings

# Ignore specific warnings from PIL
warnings.filterwarnings("ignore", "(Possibly )?corrupt EXIF data", UserWarning)

# --- Configuration ---
DATA_DIR = '/workspace/WORKS/DATA/' # !!! UPDATE THIS PATH !!!
TRAIN_CSV_PATH = os.path.join(DATA_DIR, 'CheXpert-v1.0-small/train.csv')
VALID_CSV_PATH = os.path.join(DATA_DIR, 'CheXpert-v1.0-small/valid.csv')
IMAGE_ROOT_DIR = DATA_DIR # Assuming images are relative to DATA_DIR

# Model settings
MODEL_NAME = 'vit_base_patch16_224_dino' # Using standard DINO ViT from timm
# If you have custom Rad-DINO weights:
# RAD_DINO_CHECKPOINT_PATH = '/path/to/your/rad_dino_checkpoint.pth' # !!! UNCOMMENT AND UPDATE IF NEEDED !!!
NUM_CLASSES = 14  # CheXpert has 14 labels
IMG_SIZE = 224

# Training settings
BATCH_SIZE = 32
EPOCHS = 30 # Adjust as needed
LEARNING_RATE = 1e-4 # Fine-tuning often uses smaller LR
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")

# CheXpert classes (as they appear in the CSV)
CLASSES = [
    'No Finding', 'Enlarged Cardiomediastinum', 'Cardiomegaly', 'Lung Opacity',
    'Lung Lesion', 'Edema', 'Consolidation', 'Pneumonia', 'Atelectasis',
    'Pneumothorax', 'Pleural Effusion', 'Pleural Other', 'Fracture', 'Support Devices'
]

# --- Dataset Definition ---
class CheXpertDataset(Dataset):
    def __init__(self, csv_file, image_root_dir, transform=None, policy="ones"):
        """
        Args:
            csv_file (string): Path to the csv file with annotations.
            image_root_dir (string): Directory with all the images.
            transform (callable, optional): Optional transform to be applied on a sample.
            policy (string): Policy to handle uncertain labels (-1).
                             "ones": Treat uncertain labels as positive (1).
                             "zeros": Treat uncertain labels as negative (0). (Default used here)
                             "ignore": Not implemented here, would require masking loss.
        """
        self.image_frame = pd.read_csv(csv_file)
        self.image_root_dir = image_root_dir
        self.transform = transform
        self.policy = policy

        # Prepend root dir to image paths if they are relative
        # Handle potential paths starting with 'CheXpert-v1.0/'
        def fix_path(path):
            if path.startswith('CheXpert-v1.0/'):
                path = path.replace('CheXpert-v1.0/', '', 1)
            return os.path.join(self.image_root_dir, path)

        self.image_frame['Path'] = self.image_frame['Path'].apply(fix_path)

        # Fill NaNs and handle uncertain labels
        # Select only the label columns
        self.labels_df = self.image_frame[CLASSES].copy()
        self.labels_df = self.labels_df.fillna(0) # Fill NaNs with 0 (negative)

        if self.policy == "ones":
            self.labels_df = self.labels_df.replace(-1, 1) # U-Ones policy
        else: # Default to zeros policy
            self.labels_df = self.labels_df.replace(-1, 0) # U-Zeros policy

        print(f"Loaded {csv_file}. Policy: {policy}. Number of samples: {len(self.image_frame)}")
        # print("Label distribution after processing:")
        # print(self.labels_df.sum()) # Optional: check label counts


    def __len__(self):
        return len(self.image_frame)

    def __getitem__(self, idx):
        if torch.is_tensor(idx):
            idx = idx.tolist()

        img_path = self.image_frame.iloc[idx, 0] # Path is expected to be the first column

        try:
            # Load image, convert to RGB (DINO expects 3 channels)
            image = Image.open(img_path).convert('RGB')
        except Exception as e:
            print(f"Error loading image {img_path}: {e}")
            # Return a dummy image and label or handle appropriately
            image = Image.new('RGB', (IMG_SIZE, IMG_SIZE), color = 'black')
            # Or perhaps raise an error or return None and filter in DataLoader collate_fn

        labels = self.labels_df.iloc[idx].values.astype(float)
        labels = torch.tensor(labels, dtype=torch.float32)

        if self.transform:
            image = self.transform(image)

        return image, labels

# --- Transforms ---
# Use transforms similar to DINO/ViT training (adjust if Rad-DINO used different ones)
train_transform = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(10),
    # Add more augmentations if needed (e.g., ColorJitter, RandomAffine)
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]) # ImageNet stats
])

val_transform = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]) # ImageNet stats
])

# --- Data Loaders ---
train_dataset = CheXpertDataset(csv_file=TRAIN_CSV_PATH, image_root_dir=IMAGE_ROOT_DIR, transform=train_transform, policy="zeros")
valid_dataset = CheXpertDataset(csv_file=VALID_CSV_PATH, image_root_dir=IMAGE_ROOT_DIR, transform=val_transform, policy="zeros")

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=8, pin_memory=True)
valid_loader = DataLoader(valid_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=8, pin_memory=True)

# --- Model Definition ---
print(f"Loading model: {MODEL_NAME}")
model = timm.create_model(MODEL_NAME, pretrained=True)

# --- !!! Potential Rad-DINO Loading Section !!! ---
# If you have a specific Rad-DINO checkpoint:
# 1. You might need the original model definition code if it's not standard ViT.
# 2. Load the state dict:
try:
    checkpoint = torch.load('chexpert_rad_dino_best.pth', map_location='cpu')
    # Adjust the key names if necessary (e.g., remove 'module.' prefix if saved with DataParallel)
    state_dict = checkpoint['state_dict'] # Or checkpoint['model'] or just checkpoint, depending on how it was saved
    # Filter out incompatible keys (like the final classifier head)
    model_dict = model.state_dict()
    pretrained_dict = {k: v for k, v in state_dict.items() if k in model_dict and model_dict[k].shape == v.shape}
    model_dict.update(pretrained_dict)
    missing_keys, unexpected_keys = model.load_state_dict(model_dict, strict=False)
    print(f"Loaded custom weights. Missing: {len(missing_keys)}, Unexpected: {len(unexpected_keys)}")
    # Freeze backbone layers if desired (common in fine-tuning)
    # for name, param in model.named_parameters():
    #     if not name.startswith('head'): # Freeze all except the head
    #         param.requires_grad = False
except Exception as e:
     print(f"Could not load custom Rad-DINO weights from {'chexpert_rad_dino_best.pth'}: {e}")
     print("Proceeding with standard DINO weights.")
# --- End Rad-DINO Loading Section ---


# Modify the final classification head for CheXpert (14 classes)
###
#num_ftrs = model.head.in_features # Get the number of input features for the classifier head
##########################3

if hasattr(model, 'embed_dim'):
    num_ftrs = model.embed_dim
    print(f"Usando model.embed_dim: {num_ftrs}")
elif hasattr(model, 'num_features') and model.num_features > 0: # A veces num_features es lo mismo que embed_dim en ViT
    num_ftrs = model.num_features
    print(f"Usando model.num_features: {num_ftrs}")
# ... (Otras opciones si estas fallan) ...
else:
     # Opción más genérica: mirar la capa de normalización antes de la cabeza (si existe)
     if hasattr(model, 'norm') and isinstance(model.norm, torch.nn.LayerNorm):
         num_ftrs = model.norm.normalized_shape[0]
         print(f"Usando model.norm.normalized_shape[0]: {num_ftrs}")
     else:
         # Si todo falla, inspecciona manualmente con print(model) o usa un valor conocido
         print("No se pudo determinar num_ftrs automáticamente. Inspecciona 'print(model)'.")
         # Para ViT-Base, el valor estándar suele ser 768. ¡Úsalo con precaución!
         # num_ftrs = 768
         # print(f"Usando valor predeterminado (¡PRECAUCIÓN!): {num_ftrs}")
         raise AttributeError("No se pudo determinar num_ftrs. Inspecciona la estructura del modelo.")

# Ahora puedes definir tu nueva cabeza de clasificación
# num_classes = TU_NUMERO_DE_CLASES # Define cuántas clases tienes en CheXpert
# model.head = torch.nn.Linear(num_ftrs, num_classes)




model.head = nn.Linear(num_ftrs, NUM_CLASSES) # Replace head with a new one for our task

model = model.to(DEVICE)

# --- Loss Function and Optimizer ---
# Use BCEWithLogitsLoss for multi-label classification (combines Sigmoid + BCE)
criterion = nn.BCEWithLogitsLoss()
optimizer = optim.AdamW(model.parameters(), lr=LEARNING_RATE)
# Optional: Add a learning rate scheduler
# scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.1)

# --- Training and Validation Functions ---
def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()
    running_loss = 0.0
    prog_bar = tqdm(loader, desc="Training", leave=False)
    for i, (images, labels) in enumerate(prog_bar):
        images, labels = images.to(device), labels.to(device)

        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()
        prog_bar.set_postfix(loss=loss.item())

    epoch_loss = running_loss / len(loader)
    return epoch_loss

def validate(model, loader, criterion, device):
    model.eval()
    running_loss = 0.0
    all_preds = []
    all_labels = []

    prog_bar = tqdm(loader, desc="Validation", leave=False)
    with torch.no_grad():
        for images, labels in prog_bar:
            images, labels = images.to(device), labels.to(device)

            outputs = model(images)
            loss = criterion(outputs, labels)
            running_loss += loss.item()

            # Store predictions and labels for AUC calculation
            # Apply sigmoid to get probabilities
            preds = torch.sigmoid(outputs)
            all_preds.append(preds.cpu().numpy())
            all_labels.append(labels.cpu().numpy())

            prog_bar.set_postfix(loss=loss.item())

    epoch_loss = running_loss / len(loader)

    # Calculate AUC
    all_preds = np.concatenate(all_preds, axis=0)
    all_labels = np.concatenate(all_labels, axis=0)

    auc_scores = {}
    valid_labels_auc = []
    valid_preds_auc = []
    for i in range(NUM_CLASSES):
         # Check if class has both positive and negative samples in the validation set
        if len(np.unique(all_labels[:, i])) > 1:
            auc = roc_auc_score(all_labels[:, i], all_preds[:, i])
            auc_scores[CLASSES[i]] = auc
            valid_labels_auc.append(all_labels[:, i])
            valid_preds_auc.append(all_preds[:, i])
        else:
             auc_scores[CLASSES[i]] = np.nan # Cannot compute AUC if only one class present

    # Calculate average AUC over classes where it could be computed
    valid_preds_auc_stacked = np.vstack(valid_preds_auc).T
    valid_labels_auc_stacked = np.vstack(valid_labels_auc).T
    if valid_preds_auc_stacked.size > 0 :
        avg_auc = roc_auc_score(valid_labels_auc_stacked, valid_preds_auc_stacked, average='macro')
    else:
        avg_auc = 0.0


    return epoch_loss, avg_auc, auc_scores

# --- Training Loop ---
best_val_auc = 0.0

for epoch in range(EPOCHS):
    print(f"\n--- Epoch {epoch+1}/{EPOCHS} ---")

    train_loss = train_one_epoch(model, train_loader, criterion, optimizer, DEVICE)
    print(f"Epoch {epoch+1} Training Loss: {train_loss:.4f}")

    val_loss, val_auc_avg, val_auc_scores = validate(model, valid_loader, criterion, DEVICE)
    print(f"Epoch {epoch+1} Validation Loss: {val_loss:.4f}")
    print(f"Epoch {epoch+1} Validation Avg AUC: {val_auc_avg:.4f}")
    # print("Per-class AUCs:")
    # for cls, score in val_auc_scores.items():
    #     print(f"  {cls}: {score:.4f}")

    # Optional: Update learning rate scheduler
    # scheduler.step()

    # Save the best model based on validation AUC
    if val_auc_avg > best_val_auc:
        best_val_auc = val_auc_avg
        print(f"*** New best model found! Saving model_best.pth (AUC: {best_val_auc:.4f}) ***")
        torch.save(model.state_dict(), 'chexpert_rad_dino_best.pth')

print("\n--- Training Finished ---")
print(f"Best Validation Average AUC: {best_val_auc:.4f}")

# To load the best model later:
# model.load_state_dict(torch.load('chexpert_rad_dino_best.pth'))
# model.eval()