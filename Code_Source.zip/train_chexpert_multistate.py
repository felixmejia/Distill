import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
import pandas as pd
import numpy as np
from PIL import Image
import os
import time
import argparse
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score, roc_curve, classification_report, accuracy_score, confusion_matrix
import copy # Para guardar el mejor modelo

from tqdm import tqdm


print(f"PyTorch Version: {torch.__version__}")
print(f"CUDA Available: {torch.cuda.is_available()}")
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")

# --- 1. Argument Parser ---
parser = argparse.ArgumentParser(description="Train Teacher/Student on CheXpert with 4-bit state labels")
parser.add_argument('--data_dir', type=str, required=True, help='Base directory containing CheXpert CSV files (train.csv, valid.csv, test.csv)')
parser.add_argument('--img_dir', type=str, required=True, help='Base directory containing CheXpert image folders (e.g., where CheXpert-v1.0 folder resides)')
parser.add_argument('--output_dir', type=str, default='./chexpert_output', help='Directory to save models, plots, and results')
parser.add_argument('--classes', nargs='+', default=['Atelectasis', 'Cardiomegaly', 'Consolidation', 'Edema', 'Pleural Effusion'], help='List of 5 pathology class names (columns in CSV)')
parser.add_argument('--img_size', type=int, default=224, help='Image size (input to model)')
parser.add_argument('--batch_size', type=int, default=32, help='Batch size for training and evaluation')
parser.add_argument('--epochs', type=int, default=15, help='Number of training epochs')
parser.add_argument('--lr', type=float, default=1e-4, help='Learning rate')
parser.add_argument('--num_workers', type=int, default=4, help='Number of dataloader workers')
parser.add_argument('--teacher_model', type=str, default='densenet121', help='Teacher model architecture (e.g., densenet121)')
parser.add_argument('--student_model', type=str, default='mobilenet_v2', help='Student model architecture (e.g., mobilenet_v2)')
parser.add_argument('--use_pretrained', action='store_true', help='Use ImageNet pretrained weights (affects first layer if modifying)')

args = parser.parse_args()

# --- Crear directorio de salida ---
os.makedirs(args.output_dir, exist_ok=True)

# --- Constantes ---
NUM_PATHOLOGIES = len(args.classes)
NUM_STATES = 4 # Present, Absent, Uncertain, Not Mentioned
NUM_OUTPUT_NEURONS = NUM_PATHOLOGIES * NUM_STATES # 5 * 4 = 20

if NUM_PATHOLOGIES != 5:
    raise ValueError("Este script está diseñado para exactamente 5 patologías.")

# --- 2. Dataset Definition ---
class ChexpertDatasetMultiState(Dataset):
    """
    Dataset CheXpert que devuelve etiquetas como índices de clase (0-3)
    para cada una de las 5 patologías.
    Mapping: Present=0, Absent=1, Uncertain=2, NotMentioned=3
    """
    def __init__(self, csv_path, img_dir, classes_list, transform=None, mode='train'):
        self.img_labels_df = pd.read_csv(csv_path)
        # Llenar NaNs en las columnas de etiquetas ANTES de mapear
        # Asumimos que NaNs en etiquetas significan "No Mencionado"
        self.img_labels_df[classes_list] = self.img_labels_df[classes_list].fillna(np.nan) # Asegurar que sean NaN reales
        self.img_dir = img_dir
        self.transform = transform
        self.classes = classes_list
        self.mode = mode # 'train', 'valid', 'test'

        # Mapping de valores crudos a índice de clase (0-3)
        self.state_mapping = {
            1.0: 0,  # Present
            0.0: 1,  # Absent
           -1.0: 2,  # Uncertain
            np.nan: 3 # Not Mentioned
        }

    def __len__(self):
        return len(self.img_labels_df)

    def __getitem__(self, idx):
        if torch.is_tensor(idx):
            idx = idx.tolist()

        row = self.img_labels_df.iloc[idx]
        img_path_partial = row['Path']

        # Construir ruta de imagen (¡¡¡AJUSTAR SI ES NECESARIO!!!)
        # Asume que img_dir es la carpeta que contiene 'CheXpert-v1.0/'
        # y Path es como 'CheXpert-v1.0/train/patient...'
        img_path = os.path.join(self.img_dir, img_path_partial)

        try:
            # Cargar como 'L' y convertir a 3 canales en transformaciones
            image = Image.open(img_path).convert('L')
        except FileNotFoundError:
            print(f"ADVERTENCIA: Imagen no encontrada {img_path}. Saltando índice {idx}.")
            return None # Manejar con collate_fn
        except Exception as e:
            print(f"ADVERTENCIA: Error cargando {img_path}: {e}. Saltando índice {idx}.")
            return None

        # Aplicar transformaciones
        if self.transform:
            image = self.transform(image)
        else: # Asegurar que sea un tensor si no hay transformaciones
             image = transforms.ToTensor()(image)
             if image.shape[0] == 1: # Replicar si ToTensor no creó 3 canales
                 image = image.repeat(3, 1, 1)

        # Codificar etiquetas a índices de clase (0-3)
        label_indices_list = []
        raw_labels = row[self.classes].values

        for raw_label in raw_labels:
            mapped_index = self.state_mapping.get(raw_label, self.state_mapping[np.nan]) # Default a NotMentioned si hay valor raro
            if pd.isna(raw_label): # Manejo explícito de NaN para asegurar mapeo correcto
                 mapped_index = self.state_mapping[np.nan]
            label_indices_list.append(mapped_index)

        # Convertir a LongTensor (requerido por CrossEntropyLoss)
        label_indices_tensor = torch.tensor(label_indices_list, dtype=torch.long) # Shape: (5,)

        # Retornar solo imagen y tensor de índices
        return image, label_indices_tensor

# --- Collate function para manejar errores de carga ---
def collate_fn_skip_none(batch):
    batch = list(filter(lambda x: x is not None, batch))
    if not batch:
        # Devuelve None si todo el lote falló, necesita manejo especial en el bucle
        # O devuelve tensores vacíos con forma correcta si prefieres
        print("ADVERTENCIA: Lote completo falló al cargar, devolviendo None.")
        return None, None
    return torch.utils.data.dataloader.default_collate(batch)

# --- 3. Transformaciones ---
# Usar normalización de ImageNet es común, incluso si no se usan pesos preentrenados
# Asegura que la entrada tenga 3 canales para modelos estándar
normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])

train_transform = transforms.Compose([
    transforms.Resize((args.img_size, args.img_size)),
    # Augmentations (opcional pero recomendado)
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(10),
    transforms.ColorJitter(brightness=0.1, contrast=0.1), # Ligero ajuste
    transforms.Grayscale(num_output_channels=3), # Asegura 3 canales
    transforms.ToTensor(),
    normalize,
])

val_test_transform = transforms.Compose([
    transforms.Resize((args.img_size, args.img_size)),
    transforms.Grayscale(num_output_channels=3), # Asegura 3 canales
    transforms.ToTensor(),
    normalize,
])

# --- 4. Crear Datasets y DataLoaders ---
try:
    train_dataset = ChexpertDatasetMultiState(os.path.join(args.data_dir, 'train.csv'), args.img_dir, args.classes, transform=train_transform, mode='train')
    valid_dataset = ChexpertDatasetMultiState(os.path.join(args.data_dir, 'valid.csv'), args.img_dir, args.classes, transform=val_test_transform, mode='valid')
    test_dataset = ChexpertDatasetMultiState(os.path.join(args.data_dir, 'test.csv'), args.img_dir, args.classes, transform=val_test_transform, mode='test')

    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True, collate_fn=collate_fn_skip_none)
    valid_loader = DataLoader(valid_dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True, collate_fn=collate_fn_skip_none)
    test_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True, collate_fn=collate_fn_skip_none)

    print("\n<<< Data Information >>>")
    print(f"Train data : {len(train_dataset)}")
    print(f"Valid data : {len(valid_dataset)}")
    print(f"Test data : {len(test_dataset)}")
    if len(train_dataset) == 0 or len(valid_dataset) == 0 or len(test_dataset) == 0:
         raise ValueError("Uno o más datasets están vacíos. Verifica las rutas de los CSV.")

except FileNotFoundError as e:
    print(f"\nERROR: No se encontró el archivo CSV: {e}")
    print("Por favor, asegúrate que 'train.csv', 'valid.csv', 'test.csv' existen en --data_dir")
    exit()
except ValueError as e:
     print(f"\nERROR: {e}")
     exit()

# --- 5. Model Definition ---
def create_model(model_name, num_classes_out, use_pretrained=False):
    """Crea el modelo (DenseNet o MobileNet) y ajusta la capa final."""
    model = None
    weights = None
    if use_pretrained:
        print(f"Attempting to load {model_name} with pretrained weights.")
        if model_name == 'densenet121':
            weights = models.DenseNet121_Weights.IMAGENET1K_V1
        elif model_name == 'mobilenet_v2':
            weights = models.MobileNet_V2_Weights.IMAGENET1K_V1
        # Añadir más modelos/pesos aquí si es necesario
        else:
             print(f"Advertencia: Pesos preentrenados no definidos para {model_name}. Cargando sin preentrenar.")

    print(f"Loading {model_name} architecture...")
    if model_name == 'densenet121':
        model = models.densenet121(weights=weights)
        num_ftrs = model.classifier.in_features
        model.classifier = nn.Linear(num_ftrs, num_classes_out)
        print(f"Replaced DenseNet classifier, input features: {num_ftrs}, output features: {num_classes_out}")
    elif model_name == 'mobilenet_v2':
        model = models.mobilenet_v2(weights=weights)
        num_ftrs = model.classifier[1].in_features
        model.classifier = nn.Linear(num_ftrs, num_classes_out)
        print(f"Replaced MobileNetV2 classifier, input features: {num_ftrs}, output features: {num_classes_out}")
    # Añadir más arquitecturas aquí si se desea
    else:
        raise ValueError(f"Model architecture '{model_name}' not supported.")

    # No modificamos la primera capa porque las transformaciones aseguran 3 canales de entrada

    return model

# --- 6. Loss Function ---
# Usamos CrossEntropyLoss porque tratamos esto como 5 problemas de clasificación de 4 vías
# reduction='none' para poder promediar por patología después
criterion = nn.CrossEntropyLoss(reduction='none')

# --- 7. Training and Validation Functions ---
def train_epoch(model, dataloader, criterion, optimizer, device, num_pathologies, pathology_names, current_epoch, total_epochs):
    model.train()
    total_loss = 0.0
    pathology_losses_accum = torch.zeros(num_pathologies, device=device)
    batches_processed = 0

    num_samples_processed = 0 # Contador de muestras en lugar de batches

      # Envolver dataloader con tqdm
    

    pbar = tqdm(dataloader, desc='Step at start {}; Training epoch {}/{}'.format(num_samples_processed, current_epoch+1, total_epochs), leave=False)      
    
    for images, target_indices_5 in pbar:
        # Manejar lotes vacíos si collate_fn devolvió None
        if images is None or target_indices_5 is None:
            print("Saltando lote vacío en entrenamiento.")
            continue

        images, target_indices_5 = images.to(device), target_indices_5.to(device)
        batch_size = images.size(0)
        optimizer.zero_grad()

        
        

        # Forward pass -> Salida de 20 logits
        outputs = model(images) # Shape: (batch_size, 20)


        if num_samples_processed==0:
            print("images : ", images.shape)
            print("images : ", images)
            print("target_indices_5 : ", target_indices_5.shape)
            print("target_indices_5 : ", target_indices_5)
            print("outputs : ", outputs.shape)
            print("outputs : ", outputs)


        # Reshape para calcular loss por patología
        # (batch_size, 20) -> (batch_size, 5, 4)
        outputs_reshaped = outputs.view(batch_size, num_pathologies, NUM_STATES)

        # Calcular loss por cada elemento del batch y cada patología
        # Salida de criterion: (batch_size, 5) si aplicamos sobre (batch_size, 5, 4) vs (batch_size, 5)
        # Necesitamos permutar para que la dimensión de clase sea la segunda
        # Entrada para CrossEntropy: (N, C, d1, d2..) vs (N, d1, d2..)
        # Aquí N=batch_size*5, C=4. Input: (N, C), Target: (N,)


        o=outputs_reshaped.permute(0, 2, 1).reshape(-1, NUM_STATES)
        
        loss_per_pathology = criterion(outputs_reshaped.permute(0, 2, 1).reshape(-1, NUM_STATES), # Shape: (batch*5, 4)
                                       target_indices_5.view(-1)) # Shape: (batch*5,)
        if num_samples_processed==0:
            print("out=", o.shape)
            print("out=", o)
            p=target_indices_5.view(-1)
            print("target_indices_5.view(-1)=", p.shape)
            print("target_indices_5.view(-1)=", p)
            print("loss_per_pathology : ", loss_per_pathology.shape)
            print("loss_per_pathology : ", loss_per_pathology)
            
        loss_per_pathology = loss_per_pathology.view(batch_size, num_pathologies) # Reshape back: (batch_size, 5)

        if num_samples_processed==0:
            print("loss_per_pathology : ", loss_per_pathology.shape)
            print("loss_per_pathology : ", loss_per_pathology)

        # Promediar loss por patología para este batch
        batch_pathology_losses = loss_per_pathology.mean(dim=0) # Shape: (5,)

        if num_samples_processed==0:
            print("batch_pathology_losses : ", batch_pathology_losses.shape)
            print("batch_pathology_losses : ", batch_pathology_losses)

        # Loss total del batch (promedio sobre patologías y batch)
        # batch_loss = batch_pathology_losses.detach().cpu().numpy()

        batch_loss = batch_pathology_losses.mean() # Calculate mean across pathologies - Still a Tensor

        # Backward pass y optimización
        batch_loss.backward()
        optimizer.step()

        total_loss += batch_loss.item() * batch_size # Acumular loss total ponderada por tamaño de batch
        pathology_losses_accum += batch_pathology_losses * batch_size # Acumular loss por patología ponderada
        batches_processed += batch_size # Usar número de muestras procesadas
        
        num_samples_processed += batch_size

        # Actualizar la descripción de la barra (opcional)
        pbar.set_postfix(loss=f"{batch_loss.item():.4f}")

    avg_epoch_loss = total_loss / batches_processed if batches_processed > 0 else 0
    avg_pathology_losses = pathology_losses_accum / batches_processed if batches_processed > 0 else torch.zeros(num_pathologies)

    return avg_epoch_loss, avg_pathology_losses.detach().cpu().numpy()


def validate_epoch(model, dataloader, criterion, device, num_pathologies, pathology_names, current_epoch, total_epochs):
    model.eval()
    total_loss = 0.0
    pathology_losses_accum = torch.zeros(num_pathologies, device=device)
    batches_processed = 0
    num_samples_processed = 0 # Contador de muestras

    all_outputs_reshaped = [] # Guardar salidas para métricas AUC, etc. (batch, 5, 4)
    all_target_indices = []   # Guardar target índices (batch, 5)

    pbar = tqdm(dataloader, desc=f"Epoch {current_epoch+1}/{total_epochs} [Val]  ", leave=False)


    with torch.no_grad():
        for images, target_indices_5 in pbar:
            if images is None or target_indices_5 is None:
                print("Saltando lote vacío en validación.")
                continue

            images, target_indices_5 = images.to(device), target_indices_5.to(device)
            batch_size = images.size(0)

            outputs = model(images) # Shape: (batch_size, 20)
            outputs_reshaped = outputs.view(batch_size, num_pathologies, NUM_STATES) # Shape: (batch_size, 5, 4)

            # Calcular loss (igual que en train)
            loss_per_pathology = criterion(outputs_reshaped.permute(0, 2, 1).reshape(-1, NUM_STATES),
                                           target_indices_5.view(-1))
            loss_per_pathology = loss_per_pathology.view(batch_size, num_pathologies)
            batch_pathology_losses = loss_per_pathology.mean(dim=0)
            batch_loss = batch_pathology_losses.mean()

            total_loss += batch_loss.item() * batch_size
            pathology_losses_accum += batch_pathology_losses * batch_size
            batches_processed += batch_size

            # Guardar salidas y targets para evaluación posterior
            all_outputs_reshaped.append(outputs_reshaped.cpu())
            all_target_indices.append(target_indices_5.cpu())
            # Actualizar la descripción de la barra (opcional)
            pbar.set_postfix(loss=f"{batch_loss.item():.4f}")

    avg_epoch_loss = total_loss / batches_processed if batches_processed > 0 else 0
    avg_pathology_losses = pathology_losses_accum / batches_processed if batches_processed > 0 else torch.zeros(num_pathologies)

    # Concatenar resultados de todos los batches
    final_outputs = torch.cat(all_outputs_reshaped, dim=0) if all_outputs_reshaped else torch.empty(0, num_pathologies, NUM_STATES)
    final_targets = torch.cat(all_target_indices, dim=0) if all_target_indices else torch.empty(0, num_pathologies, dtype=torch.long)

    return avg_epoch_loss, avg_pathology_losses.detach().cpu().numpy(), final_outputs, final_targets


# --- 8. Main Training Execution Function ---
def run_training(model_name_tag, model, train_loader, valid_loader, criterion, optimizer, epochs, device, num_pathologies, pathology_names, output_dir):
    print(f"\n--- Training {model_name_tag} ---")
    history = {
        'train_loss': [], 'val_loss': [],
        'train_loss_per_pathology': [[] for _ in range(num_pathologies)],
        'val_loss_per_pathology': [[] for _ in range(num_pathologies)]
    }
    best_val_loss = float('inf')
    best_model_wts = None
    start_time = time.time()

    for epoch in range(epochs):
        epoch_start_time = time.time()

        # Training
        train_loss, train_path_losses = train_epoch(model, train_loader, criterion, optimizer, device, num_pathologies, pathology_names, epoch, epochs)
        history['train_loss'].append(train_loss)
        for i in range(num_pathologies):
            history['train_loss_per_pathology'][i].append(train_path_losses[i])

        # Validation
        val_loss, val_path_losses, val_outputs, val_targets = validate_epoch(model, valid_loader, criterion, device, num_pathologies, pathology_names, epoch, epochs)
        history['val_loss'].append(val_loss)
        for i in range(num_pathologies):
            history['val_loss_per_pathology'][i].append(val_path_losses[i])

        epoch_time = time.time() - epoch_start_time
        print(f"Epoch {epoch+1}/{epochs} | Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f} | Time: {epoch_time:.2f}s")
        for i, name in enumerate(pathology_names):
             print(f"  {name}: Train Loss: {train_path_losses[i]:.4f}, Val Loss: {val_path_losses[i]:.4f}")


        # Guardar el mejor modelo basado en la pérdida de validación total
        if val_loss < best_val_loss:
            print(f"  Validation loss improved ({best_val_loss:.4f} -> {val_loss:.4f}). Saving model...")
            best_val_loss = val_loss
            best_model_wts = copy.deepcopy(model.state_dict())
            model_save_path = os.path.join(output_dir, f'{model_name_tag}_best_model.pth')
            torch.save(best_model_wts, model_save_path)

    total_training_time = time.time() - start_time
    print(f"--- Training Finished for {model_name_tag} ---")
    print(f"Total Training Time: {total_training_time // 60:.0f}m {total_training_time % 60:.0f}s")
    print(f"Best Validation Loss: {best_val_loss:.4f}")
    if best_model_wts:
         print(f"Best model saved to {model_save_path}")
         # Cargar el mejor modelo para evaluación final
         model.load_state_dict(best_model_wts)
    else:
         print("Advertencia: No se guardó ningún modelo (posiblemente no hubo mejora o error).")


    return model, history

# --- 9. Plotting Functions ---
def plot_learning_curves(history, num_pathologies, pathology_names, output_dir, model_name_tag):
    epochs_range = range(1, len(history['train_loss']) + 1)

    plt.figure(figsize=(18, 6 * (1 + num_pathologies // 2))) # Ajustar tamaño figura

    # Plot Total Loss
    plt.subplot(1 + (num_pathologies + 1) // 2, 2, 1) # Primera posición
    plt.plot(epochs_range, history['train_loss'], 'bo-', label='Training Loss')
    plt.plot(epochs_range, history['val_loss'], 'ro-', label='Validation Loss')
    plt.title(f'{model_name_tag} - Total Training & Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True)

    # Plot Loss per Pathology
    for i in range(num_pathologies):
        plt.subplot(1 + (num_pathologies + 1) // 2, 2, i + 2) # Siguientes posiciones
        plt.plot(epochs_range, history['train_loss_per_pathology'][i], 'bo-', label=f'Train Loss')
        plt.plot(epochs_range, history['val_loss_per_pathology'][i], 'ro-', label=f'Val Loss')
        plt.title(f'{model_name_tag} - Loss for {pathology_names[i]}')
        plt.xlabel('Epochs')
        plt.ylabel('Loss')
        plt.legend()
        plt.grid(True)

    plt.tight_layout(pad=3.0) # Añadir espacio entre subplots
    plot_filename = os.path.join(output_dir, f'{model_name_tag}_learning_curves.png')
    plt.savefig(plot_filename)
    print(f"Learning curves saved to {plot_filename}")
    # plt.show() # Descomentar para mostrar la gráfica interactivamente


def plot_auc_roc_curves(all_targets_binary_np, all_probs_present_np, num_pathologies, pathology_names, output_dir, model_name_tag):
    plt.figure(figsize=(10, 8))

    for i in range(num_pathologies):
        # Asegurarse que hay etiquetas positivas y negativas para calcular AUC/ROC
        if len(np.unique(all_targets_binary_np[:, i])) < 2:
            print(f"ADVERTENCIA: No se puede calcular ROC para '{pathology_names[i]}' - solo una clase presente en las etiquetas de test.")
            continue

        fpr, tpr, thresholds = roc_curve(all_targets_binary_np[:, i], all_probs_present_np[:, i])
        auc_score = roc_auc_score(all_targets_binary_np[:, i], all_probs_present_np[:, i])
        plt.plot(fpr, tpr, label=f'{pathology_names[i]} (AUC = {auc_score:.3f})')

    plt.plot([0, 1], [0, 1], 'k--', label='Random Chance')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate (FPR)')
    plt.ylabel('True Positive Rate (TPR)')
    plt.title(f'{model_name_tag} - ROC Curves per Pathology')
    plt.legend(loc="lower right")
    plt.grid(True)
    plot_filename = os.path.join(output_dir, f'{model_name_tag}_auc_roc_curves.png')
    plt.savefig(plot_filename)
    print(f"AUC ROC curves saved to {plot_filename}")
    # plt.show()

# --- 10. Evaluation Function ---
def evaluate_model(model, dataloader, criterion, device, num_pathologies, pathology_names, output_dir, model_name_tag):
    print(f"\n--- Evaluating {model_name_tag} on Test Set ---")
    # Usar validate_epoch para obtener salidas y targets del conjunto de test
    test_loss, test_path_losses, test_outputs, test_targets_indices = validate_epoch(
        model, dataloader, criterion, device, num_pathologies, pathology_names, 1, 1
    )

    print(f"Test Loss (Average): {test_loss:.4f}")
    for i, name in enumerate(pathology_names):
             print(f"  Test Loss {name}: {test_path_losses[i]:.4f}")

    # Preparar datos para métricas
    test_outputs_np = test_outputs.numpy() # Shape: (n_samples, 5, 4)
    test_targets_indices_np = test_targets_indices.numpy() # Shape: (n_samples, 5)

    # Calcular probabilidades para la clase "Presente" (índice 0) para AUC
    # Aplicar Softmax a la dimensión de estado (dim=2)
    probs = torch.softmax(test_outputs, dim=2).numpy() # Shape: (n_samples, 5, 4)
    probs_present_np = probs[:, :, 0] # Probabilidad de la clase 0 ("Presente") para cada patología. Shape: (n_samples, 5)

    # Crear etiquetas binarias para "Presente" vs "No Presente" para AUC/ROC
    # Si el índice de target es 0 (Presente), etiqueta binaria = 1, sino 0.
    targets_binary_present_np = (test_targets_indices_np == 0).astype(float) # Shape: (n_samples, 5)

    # Calcular AUC Scores
    print("\n--- AUC Scores (Present vs Others) ---")
    auc_scores = []
    valid_auc_classes = 0
    for i in range(num_pathologies):
        try:
            auc = roc_auc_score(targets_binary_present_np[:, i], probs_present_np[:, i])
            print(f"  {pathology_names[i]}: {auc:.4f}")
            auc_scores.append(auc)
            valid_auc_classes += 1
        except ValueError:
            print(f"  {pathology_names[i]}: Skipping AUC (only one class present in labels)")
            auc_scores.append(np.nan)

    if valid_auc_classes > 0:
         print(f"Macro Average AUC: {np.nanmean(auc_scores):.4f}")
    else:
         print("No valid AUC scores to average.")


    # Calcular Predicciones de Clase (índice 0-3 con mayor probabilidad)
    # Usar argmax sobre la dimensión de estado (dim=2) en los logits (test_outputs) o probs
    predicted_indices_np = np.argmax(test_outputs_np, axis=2) # Shape: (n_samples, 5)

    # Calcular Métricas de Clasificación (Precisión, Recall, F1)
    print("\n--- Classification Report (Predicted State vs True State) ---")
    # Nota: Esto compara el estado predicho (0-3) contra el estado verdadero (0-3)
    # No es directamente "accuracy" en el sentido binario usual.
    # report = classification_report(
    #     test_targets_indices_np,
    #     predicted_indices_np,
    #     target_names=[f"{name}_Pres/{name}_Abs/{name}_Unc/{name}_NM" for name in pathology_names], # Nombres largos!
    #     labels=np.arange(num_pathologies * NUM_STATES).reshape(num_pathologies, NUM_STATES), # Ajustar esto puede ser complejo
    #     zero_division=0
    # )
    # classification_report es difícil de aplicar directamente a multi-label multi-class así.
    # Vamos a hacerlo por patología:
    print("Calculating metrics per pathology (comparing predicted state 0-3 vs true state 0-3)...")
    label_names_per_state = ["Present", "Absent", "Uncertain", "Not_Mentioned"]
    all_metrics = {}
    for i in range(num_pathologies):
        print(f"\n--- Metrics for {pathology_names[i]} ---")
        path_target = test_targets_indices_np[:, i]
        path_pred = predicted_indices_np[:, i]
        try:
            report_path = classification_report(
                path_target,
                path_pred,
                target_names=label_names_per_state,
                labels=np.arange(NUM_STATES),
                zero_division=0,
                output_dict=True # Obtener como diccionario
            )
            print(classification_report(
                path_target,
                path_pred,
                target_names=label_names_per_state,
                labels=np.arange(NUM_STATES),
                zero_division=0
            ))
            all_metrics[pathology_names[i]] = report_path
            # Accuracy simple (qué porcentaje de veces acertó el estado exacto)
            acc = accuracy_score(path_target, path_pred)
            print(f"  Overall State Accuracy for {pathology_names[i]}: {acc:.4f}")
            # Matriz de Confusión
            cm = confusion_matrix(path_target, path_pred, labels=np.arange(NUM_STATES))
            print(f"  Confusion Matrix for {pathology_names[i]} (Rows: True, Cols: Pred):")
            print(f"    {label_names_per_state}")
            print(cm)

        except Exception as e:
            print(f"  Could not generate report for {pathology_names[i]}: {e}")

    # Graficar Curvas AUC-ROC
    plot_auc_roc_curves(targets_binary_present_np, probs_present_np, num_pathologies, pathology_names, output_dir, model_name_tag)

    return all_metrics


# --- 11. Main Execution ---
if __name__ == '__main__':
    print("\n--- Initializing Training ---")
    start_overall_time = time.time()

    # --- Teacher Model Training ---
    print("\n--- Setting up Teacher Model ---")
    teacher_model = create_model(args.teacher_model, NUM_OUTPUT_NEURONS, args.use_pretrained)
    teacher_model.to(DEVICE)
    # Usar DataParallel si hay múltiples GPUs (opcional)
    if torch.cuda.device_count() > 1:
        print(f"Using {torch.cuda.device_count()} GPUs for Teacher Model!")
        teacher_model = nn.DataParallel(teacher_model)

    optimizer_teacher = optim.Adam(teacher_model.parameters(), lr=args.lr)

    teacher_model, teacher_history = run_training(
        f"{args.teacher_model}_Teacher", teacher_model, train_loader, valid_loader, criterion,
        optimizer_teacher, args.epochs, DEVICE, NUM_PATHOLOGIES, args.classes, args.output_dir
    )
    plot_learning_curves(teacher_history, NUM_PATHOLOGIES, args.classes, args.output_dir, f"{args.teacher_model}_Teacher")
    teacher_metrics = evaluate_model(
        teacher_model, test_loader, criterion, DEVICE, NUM_PATHOLOGIES, args.classes, args.output_dir, f"{args.teacher_model}_Teacher"
    )


    # --- Student Model Training ---
    print("\n\n--- Setting up Student Model ---")
    student_model = create_model(args.student_model, NUM_OUTPUT_NEURONS, args.use_pretrained)
    student_model.to(DEVICE)
    if torch.cuda.device_count() > 1:
        print(f"Using {torch.cuda.device_count()} GPUs for Student Model!")
        student_model = nn.DataParallel(student_model)

    optimizer_student = optim.Adam(student_model.parameters(), lr=args.lr)

    student_model, student_history = run_training(
        f"{args.student_model}_Student", student_model, train_loader, valid_loader, criterion,
        optimizer_student, args.epochs, DEVICE, NUM_PATHOLOGIES, args.classes, args.output_dir
    )
    plot_learning_curves(student_history, NUM_PATHOLOGIES, args.classes, args.output_dir, f"{args.student_model}_Student")
    student_metrics = evaluate_model(
        student_model, test_loader, criterion, DEVICE, NUM_PATHOLOGIES, args.classes, args.output_dir, f"{args.student_model}_Student"
    )

    # --- Final Summary ---
    end_overall_time = time.time()
    total_time = end_overall_time - start_overall_time
    print("\n\n--- Experiment Finished ---")
    print(f"Total execution time: {total_time // 60:.0f}m {total_time % 60:.0f}s")
    print(f"Results, models, and plots saved in: {args.output_dir}")