'''Data Preprocessing'''

###################
## Prerequisites ##
###################
import argparse
import pandas as pd
from sklearn.model_selection import StratifiedShuffleSplit
import numpy as np # Import numpy for nan handling if needed

###  python3 run_generateCSV.py --data_dir /workspace/WORKS/DATA/CheXpert-v1.0-small/


# --- 1. Argument Parser ---
parser = argparse.ArgumentParser(description="Train Teacher/Student on CheXpert with 4-bit state labels")
parser.add_argument('--data_dir', type=str, required=True, help='Base directory containing CheXpert CSV files (train.csv, valid.csv, test.csv)')

args = parser.parse_args()

csv_path = '{0}/all.csv'.format(args.data_dir)
output_train_path = '{0}/frontal_train_85_2.csv'.format(args.data_dir)
output_test_path = '{0}/frontal_test_15_2.csv'.format(args.data_dir)


target_pathologies = [
    'Cardiomegaly',
    'Edema',
    'Consolidation',
    'Atelectasis',
    'Pleural Effusion'
]

test_split_ratio = 0.15  # Proporción para el conjunto de prueba (15%)
random_state = 42       # Para asegurar que la división sea reproducible

# --- Carga de Datos ---
try:
    print(f"Cargando el archivo CSV desde: {csv_path}")
    df = pd.read_csv(csv_path)
    print("Archivo CSV cargado exitosamente.")
    print(f"Número total de registros iniciales: {len(df)}")
except FileNotFoundError:
    print(f"Error: No se encontró el archivo CSV en la ruta especificada: {csv_path}")
    print("Por favor, verifica la ruta y asegúrate de que el archivo exista.")
    exit() # Salir si el archivo no se encuentra

# --- Filtrado de Imágenes Frontales ---
print("Filtrando para incluir solo imágenes frontales ('Frontal')...")
# Usamos .copy() para evitar SettingWithCopyWarning más adelante
df_frontal = df[df['Frontal/Lateral'] == 'Frontal'].copy()
# df_frontal = df.copy()
if len(df_frontal) == 0:
    print("Error: No se encontraron imágenes frontales ('Frontal') en la columna 'Frontal/Lateral'.")
    print("Verifica el contenido del CSV y el nombre de la columna.")
    exit()
print(f"Número de imágenes frontales encontradas: {len(df_frontal)}")

# Verifica que las columnas de patologías existen
missing_cols = [col for col in target_pathologies if col not in df_frontal.columns]
if missing_cols:
    print(f"Error: Las siguientes columnas de patologías no se encontraron en el CSV: {missing_cols}")
    exit()

# Crea la clave de estratificación combinando los valores de las columnas seleccionadas
# Convertimos NaN a '0', -1 a '-1', 1 a '1' para la clave string
# df_frontal['stratify_key'] = df_frontal[target_pathologies].replace(-1.0, 0.0).fillna(0).astype(int).astype(str).agg('_'.join, axis=1)

df_frontal['stratify_key'] = df_frontal[target_pathologies].fillna(-9999).astype(int).astype(str).agg('_'.join, axis=1)


print("Ejemplo de claves de estratificación generadas:")
print(df_frontal['stratify_key'].value_counts().head())
print(f"Número de claves únicas para estratificación: {df_frontal['stratify_key'].nunique()}")

# --- División Estratificada ---
print(f"\nRealizando la división estratificada (Test size: {test_split_ratio * 100:.1f}%)...")

# Prepara los datos para StratifiedShuffleSplit
X = df_frontal # Usaremos todo el dataframe filtrado como X
y = df_frontal['stratify_key'] # La clave combinada es nuestra 'y' para estratificar

sss = StratifiedShuffleSplit(n_splits=1, test_size=test_split_ratio, random_state=random_state)

# Obtiene los índices de entrenamiento y prueba (sss.split devuelve un generador)
try:
    train_index, test_index = next(sss.split(X, y))
except ValueError as e:
     print(f"\nError durante la división estratificada: {e}")
     print("Esto puede ocurrir si una de las 'clases' (combinaciones de patologías)")
     print("tiene menos miembros que n_splits (que es 1 en este caso, así que es raro)")
     print("o si hay un problema con los datos en las columnas de patologías.")
     # Verifica si hay clases con un solo miembro
     key_counts = df_frontal['stratify_key'].value_counts()
     single_member_classes = key_counts[key_counts < 2]
     if not single_member_classes.empty:
         print(f"\nAdvertencia: Se encontraron {len(single_member_classes)} combinaciones de patologías con un solo miembro.")
         print("Esto puede causar problemas con la estratificación estricta.")
         print("Ejemplos:", single_member_classes.head())
     exit()


# Crea los dataframes de entrenamiento y prueba usando los índices
train_df = df_frontal.iloc[train_index].copy()
test_df = df_frontal.iloc[test_index].copy()

# Elimina la columna temporal de estratificación
train_df = train_df.drop(columns=['stratify_key'])
test_df = test_df.drop(columns=['stratify_key'])

# --- Verificación ---
print("\n--- Verificación de la División ---")
print(f"Tamaño del DataFrame frontal original: {df_frontal.shape}")
print(f"Tamaño del DataFrame de entrenamiento: {train_df.shape}")
print(f"Tamaño del DataFrame de prueba:      {test_df.shape}")
print(f"Proporción de prueba esperada: {test_split_ratio:.3f}, Real: {len(test_df) / len(df_frontal):.3f}")

print("\nDistribución de Patologías (Proporciones %):")
print("-----------------------------------------------------------------------------")
print(f"{'Patología':<18} | {'Original (%)':<15} | {'Entrenamiento (%)':<20} | {'Prueba (%)':<15}")
print("-----------------------------------------------------------------------------")

for col in target_pathologies:
    original_dist = (df_frontal[col].value_counts(normalize=True) * 100).sort_index()
    train_dist = (train_df[col].value_counts(normalize=True) * 100).sort_index()
    test_dist = (test_df[col].value_counts(normalize=True) * 100).sort_index()

    # Formateo para mostrar N/A, -1, 0, 1 si existen
    labels = sorted(list(set(original_dist.index.astype(str)) | set(train_dist.index.astype(str)) | set(test_dist.index.astype(str))))

    print(f"{col:<18} | ", end="")
    print(f"{' '.join([f'{l}:{original_dist.get(float(l) if l != str(np.nan) else np.nan, 0.0):.1f}' for l in labels]):<15} | ", end="")
    print(f"{' '.join([f'{l}:{train_dist.get(float(l) if l != str(np.nan) else np.nan, 0.0):.1f}' for l in labels]):<20} | ", end="")
    print(f"{' '.join([f'{l}:{test_dist.get(float(l) if l != str(np.nan) else np.nan, 0.0):.1f}' for l in labels]):<15}")

print("-----------------------------------------------------------------------------")
print("(Nota: Las proporciones para cada valor -1.0, 0.0, 1.0, NaN deben ser similares entre Entrenamiento y Prueba)")


# --- Guardar los Archivos CSV ---
print("\nGuardando los archivos CSV resultantes...")
try:
    train_df.to_csv(output_train_path, index=False)
    print(f"Archivo de entrenamiento guardado en: {output_train_path}")
    test_df.to_csv(output_test_path, index=False)
    print(f"Archivo de prueba guardado en: {output_test_path}")
except Exception as e:
    print(f"Error al guardar los archivos CSV: {e}")

print("\n¡Proceso completado!")

