import pandas as pd
import numpy as np


def encode_labels(row, pathology_columns):
    encoding_map = {
        1.0: [1, 0, 0, 0],    # Present
        0.0: [0, 1, 0, 0],     # Absent
        -1.0: [0, 0, 1, 0],    # Uncertain
        None: [0, 0, 0, 1],    # Not Mentioned
        np.nan: [0, 0, 0, 1]   # También manejar NaN
    }
    
    encoded_labels = []
    for pathology in pathology_columns:
        encoded_labels.extend(encoding_map.get(row[pathology], [0, 0, 0, 1]))
    
    return encoded_labels


def encode_chexpert_labels(df, pathology_columns):
    """
    Codifica las etiquetas de CheXpert en representación de 4 bits.
    
    Args:
        df: DataFrame original de CheXpert
        pathology_columns: Lista de columnas que contienen las patologías a codificar
        
    Returns:
        DataFrame con las columnas originales reemplazadas por la codificación de 4 bits
    """
    # Definir el mapeo de valores a códigos de 4 bits
    encoding_map = {
        1.0: [1, 0, 0, 0],    # Present
        0.0: [0, 1, 0, 0],     # Absent
        -1.0: [0, 0, 1, 0],    # Uncertain
        None: [0, 0, 0, 1],    # Not Mentioned
        np.nan: [0, 0, 0, 1]   # También manejar NaN como Not Mentioned
    }
    
    # Crear una copia del dataframe para no modificar el original
    encoded_df = df.copy()
    
    for pathology in pathology_columns:
        # Aplicar el mapeo a cada columna de patología
        encoded_df[pathology] = encoded_df[pathology].apply(
            lambda x: encoding_map.get(x, [0, 0, 0, 1])  # Default a Not Mentioned si el valor no está en el mapa
        )
        
        # Opcional: Si prefieres columnas separadas para cada bit
        # encoded_df[[f"{pathology}_present", f"{pathology}_absent", 
        #            f"{pathology}_uncertain", f"{pathology}_not_mentioned"]] = \
        #    pd.DataFrame(encoded_df[pathology].tolist(), index=encoded_df.index)
    
    return encoded_df

# Ejemplo de uso
if __name__ == "__main__":
    # Cargar el dataset CheXpert (ajusta la ruta según tu configuración)

    path = '/workspace/WORKS/DATA'

    
    chexpert_path = "/workspace/WORKS/DATA/CheXpert-v1.0-small/valid.csv"
    chexpert_df = pd.read_csv(chexpert_path)
    
    # Definir las columnas de patologías (ajusta según tu dataset)
    pathology_columns = [
        'Atelectasis', 'Cardiomegaly', 'Consolidation', 'Edema',
        'Pleural Effusion'  # Agrega todas las patologías que necesites
    ]
    
    # Codificar el dataset
    encoded_df = encode_chexpert_labels(chexpert_df, pathology_columns)

    encoded_df['encoded_labels'] = chexpert_df.apply(lambda x: encode_labels(x, pathology_columns), axis=1)

    
    # Guardar el nuevo dataset
    output_path = "/workspace/WORKS/DATA/CheXpert-v1.0-small/valid_encoded.csv"
    encoded_df.to_csv(output_path, index=False)
    
    print(f"Dataset codificado guardado en: {output_path}")