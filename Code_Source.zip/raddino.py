import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from torchvision.models import resnet18 # Estudiante ligero
import timm # Para cargar modelos ViT (necesitarás adaptar para RadDino)
import pandas as pd
from PIL import Image
import os
import numpy as np
import copy # Para copiar el mejor modelo

# --- 1. Configuración ---
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")

# Paths (¡¡¡Actualiza estas rutas!!!)
CHEXPERT_CSV_PATH = '/workspace/WORKS/DATA/CheXpert-v1.0-small/train.csv' # Ruta al CSV de CheXpert
CHEXPERT_IMG_DIR = '/workspace/WORKS/DATA/CheXpert-v1.0-small/' # Directorio base de imágenes CheXpert
RADDIINO_CHECKPOINT_PATH = '/path/to/your/raddino_checkpoint.pth' # Ruta a los pesos de RadDino
OUTPUT_DIR = './distilled_model' # Directorio para guardar el modelo student

# Hiperparámetros
IMG_SIZE = 224
BATCH_SIZE = 16 # Ajusta según tu memoria GPU
LEARNING_RATE = 1e-4
EPOCHS = 20
TEMPERATURE = 4.0 # Temperatura para suavizar las salidas (KD)
ALPHA = 0.7 # Peso para la loss de KD (1-ALPHA para la loss de clasificación)

# Clases de CheXpert (ajusta si usas un subconjunto o mapeo diferente)
# Orden típico: Atelectasis, Cardiomegaly, Consolidation, Edema, Pleural Effusion
# Puedes obtenerlas del CSV
CHEXPERT_CLASSES = ['Atelectasis', 'Cardiomegaly', 'Consolidation', 'Edema', 'Pleural Effusion'] # Ejemplo, usa tus clases reales
NUM_CLASSES = len(CHEXPERT_CLASSES)

# --- 2. Dataset y DataLoader CheXpert ---
class ChexpertDataset(Dataset):
    def __init__(self, csv_path, img_dir, transform=None, policy="ones"):
        self.img_labels = pd.read_csv(csv_path)
        # Filtrar filas con NaN en las columnas de etiquetas relevantes si es necesario
        self.img_labels = self.img_labels.dropna(subset=CHEXPERT_CLASSES)
        self.img_dir = img_dir
        self.transform = transform
        self.policy = policy # Política para manejar valores NaN/Unmentioned (-1): 'zeros' o 'ones'

    def __len__(self):
        return len(self.img_labels)

    def __getitem__(self, idx):
        img_path_partial = self.img_labels.iloc[idx]['Path']
        # Asumiendo que 'Path' en el CSV es algo como 'CheXpert-v1.0-small/train/patient.../study.../view...jpg'
        # y tu img_dir es '/path/to/your/chexpert/images/'
        # Construye la ruta completa
        img_path = os.path.join(self.img_dir, '/'.join(img_path_partial.split('/')[1:])) # Ajusta esto si tu estructura es diferente

        try:
            # Cargar como escala de grises directamente
            image = Image.open(img_path).convert('L')
        except FileNotFoundError:
            print(f"Error: Imagen no encontrada en {img_path}")
            # Devuelve un tensor vacío o maneja el error como prefieras
            # Aquí devolvemos None para filtrarlo en el collate_fn o manejarlo en el loop
            return None, None
        except Exception as e:
            print(f"Error cargando imagen {img_path}: {e}")
            return None, None

        # Obtener etiquetas y manejar incertidumbre (-1)
        labels = self.img_labels.iloc[idx][CHEXPERT_CLASSES].values.astype(np.float32)

        if self.policy == "ones":
            labels[labels == -1] = 1 # Tratar U-Ones
        else: # policy == "zeros"
             labels[labels == -1] = 0 # Tratar U-Zeros

        labels[labels == -1] = 0 # Asegurarse que no queden -1 si hay otra política o error
        labels[pd.isna(labels)] = 0 # Tratar NaNs restantes como 0 (ausencia)

        if self.transform:
            image = self.transform(image)

        return image, torch.tensor(labels, dtype=torch.float32)

# Transformaciones
# Normalización: Usar la media/std de ImageNet es común, pero para escala de grises
# podrías calcularla sobre CheXpert o usar un valor genérico (e.g., 0.5, 0.5)
# Aquí replicamos el canal gris 3 veces ANTES de normalizar para compatibilidad con modelos preentrenados
mean = [0.485, 0.456, 0.406]
std = [0.229, 0.224, 0.225]

train_transform = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.Grayscale(num_output_channels=3), # Replicar canal para compatibilidad
    transforms.ToTensor(),
    transforms.Normalize(mean=mean, std=std)
])

# Crear Datasets (idealmente, también necesitas un split de validación)
# Aquí usamos todo para entrenamiento como ejemplo simple
train_dataset = ChexpertDataset(CHEXPERT_CSV_PATH, CHEXPERT_IMG_DIR, transform=train_transform, policy="ones")

# Filtra posibles errores de carga (None) - Mejor usar un collate_fn personalizado
# train_dataset = [item for item in train_dataset if item[0] is not None] # Simple filter

# DataLoader
# Un collate_fn para manejar errores de carga es más robusto
def collate_fn_skip_error(batch):
    batch = list(filter(lambda x: x is not None and x[0] is not None, batch))
    if not batch: return None # Si todo el batch falló
    return torch.utils.data.dataloader.default_collate(batch)

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=4, pin_memory=True, collate_fn=collate_fn_skip_error)
# val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=4, pin_memory=True, collate_fn=collate_fn_skip_error) # Necesitarías val_dataset

print(f"Dataset cargado: {len(train_dataset)} imágenes de entrenamiento.")
if len(train_dataset) == 0:
     raise ValueError("No se cargaron imágenes. Verifica las rutas y el archivo CSV.")

# --- 3. Definición de Modelos ---

# === Modelo Teacher (RadDino - ¡¡¡REEMPLAZAR ESTA SECCIÓN!!!) ===
print("Cargando modelo Teacher (RadDino)...")
# Esta es la parte MÁS CRÍTICA que debes adaptar.
# Necesitas la definición de la clase del modelo RadDino y cargar los pesos.
# Ejemplo usando un ViT genérico de 'timm' como marcador de posición:
try:
    # Intenta cargar un ViT base como ejemplo. Necesitarás el nombre exacto o la clase de RadDino.
    teacher_model = timm.create_model(
        'vit_base_patch16_224', # Usa el nombre correcto del modelo base de RadDino si lo conoces
        pretrained=False # Cargaremos nuestros propios pesos
    )
    # Ajustar el clasificador final para el número de clases de CheXpert
    num_ftrs = teacher_model.head.in_features
    teacher_model.head = nn.Linear(num_ftrs, NUM_CLASSES)

    # --- Carga de pesos preentrenados de RadDino ---
    # ¡¡¡ESTA ES LA LÍNEA CLAVE A ADAPTAR!!!
    # Asume que tienes un archivo .pth con el state_dict
    print(f"Intentando cargar pesos del Teacher desde: {RADDIINO_CHECKPOINT_PATH}")
    if os.path.exists(RADDIINO_CHECKPOINT_PATH):
         # Carga los pesos. Puede que necesites ajustar las claves si el state_dict
         # no coincide exactamente (e.g., si se guardó con DataParallel o tiene prefijos).
         checkpoint = torch.load(RADDIINO_CHECKPOINT_PATH, map_location='cpu')
         # Intenta cargar directamente. Puede fallar si las claves no coinciden.
         # Comunes problemas: 'module.' prefix si se guardó con DataParallel
         # state_dict = checkpoint['state_dict'] # A veces los pesos están dentro de una clave
         state_dict = checkpoint
         # Corregir prefijo 'module.' si existe
         new_state_dict = {}
         for k, v in state_dict.items():
             name = k[7:] if k.startswith('module.') else k
             new_state_dict[name] = v
         teacher_model.load_state_dict(new_state_dict, strict=False) # strict=False puede ayudar si hay capas extra/faltantes (e.g., clasificador)
         print("Pesos del Teacher (RadDino) cargados exitosamente.")
    else:
        print(f"ADVERTENCIA: No se encontró el checkpoint del Teacher en {RADDIINO_CHECKPOINT_PATH}. El Teacher no estará preentrenado.")

    teacher_model.to(DEVICE)
    teacher_model.eval() # Teacher siempre en modo evaluación para KD

except Exception as e:
    print(f"\n*** ERROR CRÍTICO CARGANDO EL MODELO TEACHER (RadDino) ***")
    print(f"Error: {e}")
    print("Por favor, revisa la sección 'Modelo Teacher' en el código.")
    print("Necesitas:")
    print("1. La definición correcta de la clase/arquitectura de RadDino.")
    print("2. La ruta correcta al archivo de checkpoint (.pth).")
    print("3. Asegurarte de que las claves en el state_dict coincidan con el modelo.")
    print("Usar un ViT genérico de 'timm' probablemente NO funcionará directamente.")
    print("Abortando ejecución.")
    exit() # Salir si no se puede cargar el teacher correctamente

# === Modelo Student (más ligero) ===
print("Cargando modelo Student...")
student_model = resnet18(weights=None) # Cargar sin pesos predeterminados de ImageNet

# Modificar la primera capa convolucional para aceptar 1 canal (escala de grises)
# PERO como replicamos a 3 canales en la transformación, NO necesitamos esto:
# student_model.conv1 = nn.Conv2d(1, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False)

# Modificar la última capa (clasificador) para el número de clases de CheXpert
num_ftrs_student = student_model.fc.in_features
student_model.fc = nn.Linear(num_ftrs_student, NUM_CLASSES)
student_model.to(DEVICE)

print("Modelos Teacher y Student listos.")

# --- 4. Función de Pérdida para Knowledge Distillation ---
def distillation_loss(student_logits, teacher_logits, labels, temperature, alpha):
    """
    Calcula la pérdida combinada de KD y clasificación estándar.
    Args:
        student_logits: Salidas crudas (logits) del modelo student.
        teacher_logits: Salidas crudas (logits) del modelo teacher.
        labels: Etiquetas verdaderas (ground truth).
        temperature: Factor para suavizar las probabilidades.
        alpha: Peso para la pérdida de KD. (1-alpha) será el peso para la CE.
    """
    # Pérdida de clasificación estándar (para multi-label con logits)
    # BCEWithLogitsLoss es estable numéricamente y combina Sigmoid + BCELoss
    loss_ce = F.binary_cross_entropy_with_logits(student_logits, labels)

    # Pérdida de Knowledge Distillation (usando KL Divergence)
    # Suavizar logits con temperatura y aplicar Sigmoid para obtener probabilidades 'suaves'
    p_student = torch.sigmoid(student_logits / temperature)
    p_teacher = torch.sigmoid(teacher_logits / temperature)

    # KL Divergence para distribuciones Bernoulli (común en multi-label KD)
    # KL(P||Q) = sum P*log(P/Q) = sum P*logP - P*logQ
    # Cuidado con log(0) o log(1) -> usar un epsilon pequeño
    epsilon = 1e-7
    kl_div = F.kl_div(
        torch.log(p_student + epsilon), # Log de la predicción del student
        p_teacher,                   # Predicción del teacher (no necesita log aquí con reduction='batchmean')
        reduction='batchmean'        # Promedio sobre el batch
    ) * (temperature ** 2) # Escalar por T^2 como es común en KD

    # Alternativa: MSE sobre los logits (a veces más simple y efectivo)
    # loss_kd = F.mse_loss(student_logits, teacher_logits)

    # Combinar las pérdidas
    total_loss = alpha * kl_div + (1.0 - alpha) * loss_ce
    # total_loss = alpha * loss_kd + (1.0 - alpha) * loss_ce # Si usas MSE

    return total_loss, loss_ce, kl_div # Devolver todas para monitoreo

# --- 5. Bucle de Entrenamiento ---
optimizer = optim.Adam(student_model.parameters(), lr=LEARNING_RATE)
# scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=7, gamma=0.1) # Opcional

os.makedirs(OUTPUT_DIR, exist_ok=True)
best_loss = float('inf') # O usa una métrica de validación si tienes val_loader

print("\n--- Iniciando Entrenamiento ---")
for epoch in range(EPOCHS):
    student_model.train() # Poner student en modo entrenamiento
    running_loss = 0.0
    running_loss_ce = 0.0
    running_loss_kd = 0.0
    processed_batches = 0

    for i, data in enumerate(train_loader):
        # Manejar batches vacíos si collate_fn devolvió None
        if data is None:
            print(f"Skipping empty batch at step {i}")
            continue

        inputs, labels = data
        inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)

        optimizer.zero_grad()

        # Obtener logits del teacher (sin calcular gradientes)
        with torch.no_grad():
            teacher_logits = teacher_model(inputs)

        # Obtener logits del student
        student_logits = student_model(inputs)

        # Calcular pérdida de KD
        loss, loss_ce, loss_kd = distillation_loss(
            student_logits, teacher_logits, labels, TEMPERATURE, ALPHA
        )

        # Backpropagation y optimización (solo para el student)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()
        running_loss_ce += loss_ce.item()
        running_loss_kd += loss_kd.item()
        processed_batches += 1

        if (i + 1) % 100 == 0: # Imprimir progreso cada 100 batches
             print(f'[Epoch {epoch + 1}/{EPOCHS}, Batch {i + 1}/{len(train_loader)}] '
                   f'Loss Total: {running_loss / processed_batches:.4f} | '
                   f'Loss CE: {running_loss_ce / processed_batches:.4f} | '
                   f'Loss KD: {running_loss_kd / processed_batches:.4f}')

    epoch_loss = running_loss / processed_batches if processed_batches > 0 else 0

    print(f"\nEpoch {epoch + 1} Completo. Loss promedio: {epoch_loss:.4f}")

    # Aquí iría la Validación (si tienes val_loader)
    # student_model.eval()
    # val_loss = 0.0
    # with torch.no_grad():
    #     for val_data in val_loader:
    #         # ... calcular loss en validación (solo CE usualmente) ...
    # if val_loss < best_loss:
    #     best_loss = val_loss
    #     best_model_wts = copy.deepcopy(student_model.state_dict())
    #     torch.save(best_model_wts, os.path.join(OUTPUT_DIR, 'best_student_model.pth'))
    #     print("Modelo mejorado guardado.")

    # Guardar el modelo de la última época como ejemplo si no hay validación
    if processed_batches > 0: # Solo guardar si el epoch tuvo datos
        current_loss = epoch_loss # Usar loss de entrenamiento si no hay validación
        if current_loss < best_loss:
             best_loss = current_loss
             print(f"Guardando modelo de la época {epoch + 1} con loss {best_loss:.4f}")
             torch.save(student_model.state_dict(), os.path.join(OUTPUT_DIR, 'best_student_model.pth'))

    # Actualizar learning rate si se usa scheduler
    # scheduler.step()

print("\n--- Entrenamiento Finalizado ---")

# Guardar el modelo final
final_model_path = os.path.join(OUTPUT_DIR, 'final_student_model.pth')
torch.save(student_model.state_dict(), final_model_path)
print(f"Modelo student final guardado en: {final_model_path}")
print(f"Mejor modelo (basado en loss de entrenamiento) guardado en: {os.path.join(OUTPUT_DIR, 'best_student_model.pth')}")