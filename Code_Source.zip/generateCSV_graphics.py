import pandas as pd
import numpy as np
import os
import argparse
import matplotlib.pyplot as plt
import seaborn as sns
from math import pi

from sklearn.model_selection import StratifiedShuffleSplit


def plot_stacked_bars(train_df, test_df, pathologies, output_path):
    """Horizontal stacked bar chart showing pathology distribution."""
    train_counts = train_df[pathologies].sum()
    test_counts = test_df[pathologies].sum()

    df_plot = pd.DataFrame({'Train': train_counts, 'Test': test_counts}, index=pathologies)
    ax = df_plot.plot.barh(stacked=True, figsize=(10, 6), color=['skyblue', 'lightcoral'])

    for p in ax.patches:
        width, height = p.get_width(), p.get_height()
        x, y = p.get_xy()
        ax.annotate(f'{width:.0f}', (x + width/2, y + height/2), ha='center', va='center', color='black')

    plt.title('Pathology Distribution (Stacked Horizontal Bars)')
    plt.xlabel('Number of Cases')
    plt.ylabel('Pathologies')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close() # Close to free memory
    print(f"Stacked bar chart saved to: {output_path}")

def plot_radar_chart(train_df, test_df, pathologies, output_path):
    """Radar chart comparing pathology distribution."""
    train_counts = train_df[pathologies].sum()
    test_counts = test_df[pathologies].sum()

    labels = pathologies
    train_data = train_counts.values
    test_data = test_counts.values

    angles = np.linspace(0, 2*np.pi, len(labels), endpoint=False)
    angles = np.concatenate((angles, [angles[0]]))

    train_data = np.concatenate((train_data, [train_data[0]]))
    test_data = np.concatenate((test_data, [test_data[0]]))

    fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(polar=True))
    ax.plot(angles, train_data, 'b-', linewidth=2, label='Train')
    ax.fill(angles, train_data, 'b', alpha=0.25)
    ax.plot(angles, test_data, 'r-', linewidth=2, label='Test')
    ax.fill(angles, test_data, 'r', alpha=0.25)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels)
    ax.set_title('Pathology Distribution (Radar Chart)')
    ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1))

    plt.tight_layout()
    plt.savefig(output_path)
    plt.close() # Close to free memory
    print(f"Radar chart saved to: {output_path}")

def plot_histograms(train_df, test_df, pathologies, output_dir):
    """Histograms for each pathology in train and test sets."""
    for pathology in pathologies:
        plt.figure(figsize=(8, 6))
        plt.hist(train_df[pathology], bins=4, alpha=0.5, label='Train', color='skyblue')
        plt.hist(test_df[pathology], bins=4, alpha=0.5, label='Test', color='lightcoral')
        plt.title(f'Distribution of {pathology} (0=Absent/Not Mentioned, 1=Present/Uncertain)')
        plt.xlabel(pathology)
        plt.ylabel('Number of Patients')
        plt.legend(loc='upper right')
        plt.tight_layout()
        hist_path = os.path.join(output_dir, f'{pathology}_histogram_2.png')
        plt.savefig(hist_path)
        plt.close() # Close to free memory


# Intentar importar la función de división estratificada multi-etiqueta
try:
    from skmultilearn.model_selection import iterative_train_test_split
    HAS_SKMULTILEARN = True
except ImportError:
    print("ADVERTENCIA: 'scikit-multilearn' no encontrada. Se usará división aleatoria simple como fallback.")
    print("Para estratificación multi-etiqueta, instala con: pip install scikit-multilearn iterative-stratification")
    from sklearn.model_selection import train_test_split
    HAS_SKMULTILEARN = False

# --- 1. Argument Parser ---
parser = argparse.ArgumentParser(description="Stratified Split of CheXpert Train Data and Analysis")
parser.add_argument('--train_csv', type=str, default='/workspace/WORKS/DATA/CheXpert-v1.0-small/train.csv', required=False, help='Path to the original CheXpert train.csv file')
parser.add_argument('--output_dir', type=str, default='./chexpert_split_output', help='Directory to save new CSV files and plots')
parser.add_argument('--classes', nargs='+', default=['Atelectasis', 'Cardiomegaly', 'Consolidation', 'Edema', 'Pleural Effusion'], help='List of 5 pathology class names')
parser.add_argument('--test_size', type=float, default=0.2, help='Proportion of the data to use for the new test set (e.g., 0.2 for 20%)')
parser.add_argument('--random_seed', type=int, default=42, help='Random seed for reproducibility')
# Política para binarizar etiquetas para estratificación y análisis de prevalencia
# U-Ones: 1.0 y -1.0 -> 1, resto -> 0
# U-Zeros: 1.0 -> 1, resto -> 0
parser.add_argument('--uncertainty_policy', type=str, default='U-Ones', choices=['U-Ones', 'U-Zeros'], help='Policy for binary labels (U-Ones or U-Zeros)')

args = parser.parse_args()

# --- Crear directorio de salida ---
os.makedirs(args.output_dir, exist_ok=True)

# --- Constantes ---
PATHOLOGIES = args.classes
if len(PATHOLOGIES) != 5:
    print("ADVERTENCIA: Se esperan 5 patologías para el análisis y gráficos estándar.")
    # Podría continuar, pero los gráficos podrían necesitar ajustes

# --- 2. Cargar Datos Originales ---
try:
    print(f"Cargando datos desde: {args.train_csv}")
    df_original_train = pd.read_csv(args.train_csv)
    df=df_original_train
    print(f"Cargadas {len(df_original_train)} filas.")
    # Validar columnas de patologías
    if not all(col in df_original_train.columns for col in PATHOLOGIES):
         missing = [col for col in PATHOLOGIES if col not in df_original_train.columns]
         raise ValueError(f"El CSV original no contiene las columnas: {missing}")
except FileNotFoundError:
    print(f"ERROR: No se encontró el archivo CSV en {args.train_csv}")
    exit()
except ValueError as e:
    print(f"ERROR: {e}")
    exit()
except Exception as e:
    print(f"ERROR inesperado al cargar el CSV: {e}")
    exit()

# --- 3. Preparar Etiquetas Binarias para Estratificación ---
print(f"Preparando etiquetas binarias con política: {args.uncertainty_policy}")
y_binary = df_original_train[PATHOLOGIES].copy()
y_binary = y_binary.fillna(0) # NaN (Not Mentioned) -> 0

if args.uncertainty_policy == 'U-Ones':
    y_binary = y_binary.replace(-1.0, 1.0) # Uncertain (-1) -> 1
else: # U-Zeros
    y_binary = y_binary.replace(-1.0, 0.0) # Uncertain (-1) -> 0

# Asegurar que solo queden 0 y 1
y_binary = y_binary.applymap(lambda x: 1 if x == 1.0 else 0)
y_binary_np = y_binary.astype(int).values # Matriz NumPy (N_samples, 5)

# --- 4. Dividir Datos ---
# Usar los índices del DataFrame como X para la división
X_indices = np.arange(len(df_original_train)).reshape(-1, 1)
train_indices, test_indices = None, None



if HAS_SKMULTILEARN:
    print(f"\n--- Realizando División Estratificada Multi-Etiqueta (Test Size: {args.test_size*100:.0f}%) ---")
    try:
        # Dividir índices usando iterative_train_test_split
        train_indices_i, y_train_i, test_indices_i, y_test_i = iterative_train_test_split(
            X_indices, y_binary_np, test_size=args.test_size
        )
        train_indices = train_indices_i.flatten()
        test_indices = test_indices_i.flatten()
        print("División estratificada multi-etiqueta completada.")
    except Exception as e:
        print(f"\nERROR durante la estratificación multi-etiqueta: {e}")
        print("Puede ocurrir si alguna patología es extremadamente rara después de binarizar.")
        print("Revirtiendo a división aleatoria simple.")
        HAS_SKMULTILEARN = False # Forzar fallback

# Fallback a división aleatoria si no se pudo estratificar
if train_indices is None or test_indices is None:
    print(f"\n--- Realizando División Aleatoria Simple (Test Size: {args.test_size*100:.0f}%) ---")
    try:
         # Si no se importó antes, importar ahora
         if not HAS_SKMULTILEARN: from sklearn.model_selection import train_test_split

         train_indices, test_indices = train_test_split(
             X_indices.flatten(), # Pasar indices 1D
             test_size=args.test_size,
             random_state=args.random_seed,
             shuffle=True
         )
         print("División aleatoria completada.")
    except Exception as e:
        print(f"ERROR fatal durante la división aleatoria: {e}")
        exit()

# --- 5. Crear y Guardar Nuevos DataFrames ---
df_train_new = df_original_train.iloc[train_indices].reset_index(drop=True)
df_test_new = df_original_train.iloc[test_indices].reset_index(drop=True)

print("\n--- Tamaños de los Conjuntos Generados ---")
print(f"Nuevo Train: {len(df_train_new)} muestras")
print(f"Nuevo Test:  {len(df_test_new)} muestras")

train_save_path = os.path.join(args.output_dir, 'train_stratified_split.csv' if HAS_SKMULTILEARN else 'train_random_split.csv')
test_save_path = os.path.join(args.output_dir, 'test_stratified_split.csv' if HAS_SKMULTILEARN else 'test_random_split.csv')

try:
    df_train_new.to_csv(train_save_path, index=False)
    df_test_new.to_csv(test_save_path, index=False)
    print(f"Nuevos archivos CSV guardados en: {args.output_dir}")
except Exception as e:
    print(f"ERROR al guardar los nuevos archivos CSV: {e}")

# --- 6. Análisis y Visualización de Distribuciones ---
print("\n--- Analizando Distribuciones de Patologías ---")

# Calcular proporciones de la clase positiva (según la política U-Ones/U-Zeros)
def calculate_positive_proportion(df, policy):
    props = {}
    total_samples = len(df)
    if total_samples == 0: return {p: 0.0 for p in PATHOLOGIES}

    y_binary_df = df[PATHOLOGIES].copy().fillna(0)
    if policy == 'U-Ones':
        y_binary_df = y_binary_df.replace(-1.0, 1.0)
    else: # U-Zeros
        y_binary_df = y_binary_df.replace(-1.0, 0.0)
    y_binary_df = y_binary_df.applymap(lambda x: 1 if x == 1.0 else 0)

    for pathology in PATHOLOGIES:
        positive_count = y_binary_df[pathology].sum()
        props[pathology] = positive_count / total_samples
    return props

train_props = calculate_positive_proportion(df_train_new, args.uncertainty_policy)
test_props = calculate_positive_proportion(df_test_new, args.uncertainty_policy)
original_props = calculate_positive_proportion(df_original_train, args.uncertainty_policy)

print("\nProporción de Casos Positivos (según política):")
print(f"{'Patología':<20} | {'Original Train':<15} | {'Nuevo Train':<15} | {'Nuevo Test':<15}")
print("-" * 70)
for p in PATHOLOGIES:
    print(f"{p:<20} | {original_props.get(p, 0):<15.3f} | {train_props.get(p, 0):<15.3f} | {test_props.get(p, 0):<15.3f}")

# --- 6.1 Gráficas de Barras Comparativas ---
print("\nGenerando gráficas de barras...")
n_pathologies = len(PATHOLOGIES)
bar_width = 0.35
index = np.arange(n_pathologies)

fig_bar, ax_bar = plt.subplots(figsize=(12, 7))

bar1 = ax_bar.bar(index - bar_width/2, [train_props.get(p, 0) for p in PATHOLOGIES], bar_width, label='Nuevo Train Set', color='skyblue')
bar2 = ax_bar.bar(index + bar_width/2, [test_props.get(p, 0) for p in PATHOLOGIES], bar_width, label='Nuevo Test Set', color='lightcoral')

ax_bar.set_xlabel('Patologías')
ax_bar.set_ylabel(f'Proporción de Positivos ({args.uncertainty_policy})')
ax_bar.set_title('Distribución de Patologías Positivas en los Conjuntos Generados')
ax_bar.set_xticks(index)
ax_bar.set_xticklabels(PATHOLOGIES, rotation=45, ha="right")
ax_bar.legend()
ax_bar.grid(axis='y', linestyle='--', alpha=0.7)
ax_bar.set_ylim(0, max(max(train_props.values()), max(test_props.values())) * 1.15) # Ajustar límite Y

# Añadir valores encima de las barras
def autolabel(bars):
    for bar in bars:
        height = bar.get_height()
        ax_bar.annotate(f'{height:.2f}',
                        xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, 3),  # 3 points vertical offset
                        textcoords="offset points",
                        ha='center', va='bottom', fontsize=9)
autolabel(bar1)
autolabel(bar2)

plt.tight_layout()
bar_plot_path = os.path.join(args.output_dir, 'pathology_distribution_bars.png')
plt.savefig(bar_plot_path)
print(f"Gráfica de barras guardada en: {bar_plot_path}")
plt.close(fig_bar)

# --- 6.2 Gráfica de Radar (Spyder) ---
print("\nGenerando gráfica de radar...")

labels = np.array(PATHOLOGIES)
train_values = np.array([train_props.get(p, 0) for p in PATHOLOGIES])
test_values = np.array([test_props.get(p, 0) for p in PATHOLOGIES])

# Cerrar el círculo añadiendo el primer valor al final
train_values_radar = np.concatenate((train_values, [train_values[0]]))
test_values_radar = np.concatenate((test_values, [test_values[0]]))
angles = np.linspace(0, 2 * pi, n_pathologies, endpoint=False).tolist()
angles += angles[:1] # Cerrar el círculo

fig_radar, ax_radar = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True))

# Dibujar ejes y líneas
ax_radar.plot(angles, train_values_radar, 'o-', linewidth=2, label='Nuevo Train Set', color='skyblue')
ax_radar.fill(angles, train_values_radar, 'skyblue', alpha=0.4)
ax_radar.plot(angles, test_values_radar, 'o-', linewidth=2, label='Nuevo Test Set', color='lightcoral')
ax_radar.fill(angles, test_values_radar, 'lightcoral', alpha=0.4)

# Etiquetas de los ejes
ax_radar.set_xticks(angles[:-1])
ax_radar.set_xticklabels(labels)

# Ajustar límites radiales (ej: 0 a max proporción + 10%)
max_val = max(train_values.max(), test_values.max())
ax_radar.set_yticks(np.linspace(0, max_val * 1.1, 5)) # 5 ticks radiales
ax_radar.set_yticklabels([f"{i:.2f}" for i in np.linspace(0, max_val * 1.1, 5)])
ax_radar.set_ylim(0, max_val * 1.1)

plt.title(f'Distribución de Prevalencia ({args.uncertainty_policy}) - Train vs Test', size=16, y=1.1)
ax_radar.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1))

radar_plot_path = os.path.join(args.output_dir, 'pathology_distribution_radar.png')
plt.savefig(radar_plot_path, bbox_inches='tight') # bbox_inches para que quepa la leyenda
print(f"Gráfica de radar guardada en: {radar_plot_path}")
plt.close(fig_radar)

print("\n--- Análisis y Visualización Completados ---")

##############################################################################################
#
# --- 4. Handle Original States and Create Stratify Key ---
#  Mapea los estados originales a enteros: Present=1, Absent=0, Uncertain=1, Not Mentioned=0
#  Puedes ajustar esta lógica si prefieres otra forma de manejar "Uncertain".
def map_states(value):
    if pd.isna(value):  # Not Mentioned
        return 0
    elif value == -1.0: # Uncertain
         return 1
    elif value == 1.0: # Present
         return 1
    elif value == 1.0: # Absent
         return 1
    else:               # Present (1.0) o Absent (0.0)
        return 0

for col in PATHOLOGIES:
    df[col] = df[col].apply(map_states)

 
# Crea la clave para StratifiedShuffleSplit combinando los estados de las patologías.
df['stratify_key'] = df[PATHOLOGIES].astype(str).agg('_'.join, axis=1)

# --- 5. Stratified Split ---
print("\nPerforming StratifiedShuffleSplit...")
sss = StratifiedShuffleSplit(n_splits=1, test_size=args.test_size, random_state=args.random_seed)

for train_index, test_index in sss.split(df, df['stratify_key']):
    train_df = df.iloc[train_index]
    test_df = df.iloc[test_index]

print(f"Train set size: {len(train_df)}")
print(f"Test set size: {len(test_df)}")

# --- 6. Save Test CSV ---
test_csv_path = os.path.join(args.output_dir, 'test.csv')
test_df.to_csv(test_csv_path, index=False)

train_csv_path = os.path.join(args.output_dir, 'train.csv')
train_df.to_csv(train_csv_path, index=False)


print(f"\nTest CSV saved to: {test_csv_path}")

plot_stacked_bars(train_df, test_df, PATHOLOGIES, os.path.join(args.output_dir, 'stacked_bar_2.png') )

plot_histograms(train_df, test_df, PATHOLOGIES, args.output_dir)

plot_radar_chart(train_df, test_df, PATHOLOGIES, os.path.join(args.output_dir, 'radar_chart_2.png') )