# Use XRV transforms to crop and resize the images
import torch
import torch.nn.functional as F
import torchvision, torchvision.transforms

import torchxrayvision as xrv


transforms = torchvision.transforms.Compose([xrv.datasets.XRayCenterCrop(),
xrv.datasets.XRayResizer(224)])
# Load Google dataset and PyTorch dataloader
dataset = xrv.datasets.NIH_Google_Dataset(imgpath="/workspace/WORKS/DATA/CheXpert-v1.0-small/", transform=transforms)
dataloader = torch.utils.data.DataLoader(dataset, batch_size=8)
# Load pre-trained model and erase classifier
model = xrv.models.DenseNet(weights="densenet121-res224-all")
model.op_threshs = None # prevent pre-trained model calibration
model.classifier = torch.nn.Linear(1024,1) # reinitialize classifier


optimizer = torch.optim.Adam(model.classifier.parameters()) # only train classifier
criterion = torch.nn.BCEWithLogitsLoss()
# training loop
for batch in dataloader:
    outputs = model(batch["img"])
    targets = batch["lab"][:, dataset.pathologies.index("Lung Opacity"), None]
    loss = criterion(outputs, targets)
    loss.backward()
    optimizer.step()