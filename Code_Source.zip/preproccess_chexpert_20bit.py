import pandas as pd
import numpy as np
import os
import argparse

# --- Configuración ---
parser = argparse.ArgumentParser(description="Preprocess CheXpert CSVs to add 20-bit labels")
parser.add_argument('--data_dir', type=str, required=True, help='Directory containing original train.csv, valid.csv, test.csv')
parser.add_argument('--output_dir', type=str, required=False, default='./chexpert_output_20Bits', help='Directory to save the new CSV files (_20bit.csv)')
parser.add_argument('--pathologies', nargs='+', default=['Atelectasis', 'Cardiomegaly', 'Consolidation', 'Edema', 'Pleural Effusion'], help='List of 5 pathology class names')
args = parser.parse_args()

os.makedirs(args.output_dir, exist_ok=True)

# Mapping de valores crudos a vector binario de 4 bits
# Usamos listas para facilitar la creación
label_map = {
    1.0:    [1.0, 0.0, 0.0, 0.0],  # Present
    0.0:    [0.0, 1.0, 0.0, 0.0],  # Absent
   -1.0:    [0.0, 0.0, 1.0, 0.0],  # Uncertain
    np.nan: [0.0, 0.0, 0.0, 1.0]   # Not Mentioned
}
state_suffixes = ['_Present', '_Absent', '_Uncertain', '_NotMentioned'] # Sufijos para nuevas columnas

# Procesar cada archivo (train, valid, test)
for split in ['train_stratified_split', 'valid', 'test_stratified_split']:
    input_csv_path = os.path.join(args.data_dir, f'{split}.csv')
    output_csv_path = os.path.join(args.data_dir, f'{split}_20bit.csv')

    if not os.path.exists(input_csv_path):
        print(f"ADVERTENCIA: Archivo {input_csv_path} no encontrado. Saltando...")
        continue

    print(f"Procesando {input_csv_path}...")
    df = pd.read_csv(input_csv_path)

    # Lista para nombres de las nuevas 20 columnas
    new_label_columns = []

    # Generar las 20 columnas
    for pathology in args.pathologies:
        if pathology not in df.columns:
             print(f"ADVERTENCIA: Columna '{pathology}' no encontrada en {input_csv_path}. Saltando patología.")
             continue

        # Crear nombres para las 4 nuevas columnas de esta patología
        state_cols = [f"{pathology}{suffix}" for suffix in state_suffixes]
        new_label_columns.extend(state_cols)

        # Función para aplicar a cada fila para obtener el vector de 4 bits
        def get_4bit_vector(value):
            # Manejar NaN explícitamente primero
            if pd.isna(value):
                return label_map[np.nan]
            # Buscar el valor en el mapa (puede ser 1.0, 0.0, -1.0)
            return label_map.get(float(value), label_map[np.nan]) # Default a NotMentioned si hay valor raro

        # Aplicar la función y expandir el resultado en las 4 nuevas columnas
        df[state_cols] = df[pathology].apply(lambda x: pd.Series(get_4bit_vector(x)))

    print(f"Nuevas columnas generadas: {len(new_label_columns)}")

    # Guardar el DataFrame modificado
    # Opcional: puedes eliminar las columnas originales de patologías si quieres
    # df = df.drop(columns=args.pathologies)
    df.to_csv(output_csv_path, index=False)
    print(f"Archivo guardado: {output_csv_path}")

print("\nPreprocesamiento completado.")