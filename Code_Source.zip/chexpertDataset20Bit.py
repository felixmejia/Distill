import torch
from torch.utils.data import Dataset
from PIL import Image
import os
import pandas as pd
import numpy as np # Necesario para manejar NaN y usar np.nan

class ChexpertDataset20Bit(Dataset):
    """
    Dataset para CheXpert que genera etiquetas en formato 20-bit.
    Cada una de las 5 patologías se representa con 4 bits:
    [Presente, Ausente, Incierto, No Mencionado]
    Ej: Presente = [1,0,0,0], Ausente = [0,1,0,0], etc.
    """
    def __init__(self, csv_path, img_dir, classes_list, transform=None):
        """
        Args:
            csv_path (string): Ruta al archivo CSV con etiquetas y rutas de imágenes.
            img_dir (string): Directorio raíz donde se encuentran las imágenes.
                                (ej: /path/to/CheXpert-v1.0/)
            classes_list (list): Lista de strings con los nombres de las 5 columnas
                                 de patologías a usar.
            transform (callable, optional): Transformaciones a aplicar a las imágenes.
        """
        self.img_labels_df = pd.read_csv(csv_path)
        # Considera manejar aquí NaNs en la columna 'Path' si existen
        # self.img_labels_df['Path'] = self.img_labels_df['Path'].fillna('')
        self.img_dir = img_dir
        self.transform = transform
        self.classes = classes_list # ej: ['Atelectasis', ..., 'Pleural Effusion']

        if len(self.classes) != 5:
            raise ValueError("Se esperan exactamente 5 clases para la codificación de 20 bits.")

        # Definimos los vectores one-hot para cada estado para claridad y eficiencia
        # Usamos listas por ahora, se convertirán a tensor al final
        self.present_vec = [1.0, 0.0, 0.0, 0.0]
        self.absent_vec = [0.0, 1.0, 0.0, 0.0]
        self.uncertain_vec = [0.0, 0.0, 1.0, 0.0]
        self.notmentioned_vec = [0.0, 0.0, 0.0, 1.0] # Para NaN o no mencionado


    def __len__(self):
        return len(self.img_labels_df)

    def __getitem__(self, idx):
        """
        Retorna la imagen transformada y el tensor de etiquetas de 20 bits.
        """
        if torch.is_tensor(idx):
            idx = idx.tolist()

        # Obtener la fila de datos para el índice dado
        row = self.img_labels_df.iloc[idx]
        img_path_partial = row['Path']

        # --- Construcción de la Ruta de la Imagen ---
        # ¡¡¡IMPORTANTE!!! Ajusta esta lógica según cómo esté estructurado tu `img_dir`
        # y el contenido de la columna 'Path' en tu CSV.
        # Ejemplo común: Path es 'CheXpert-v1.0/train/patient.../study.../view.jpg'
        # y img_dir es '/ruta/a/tus/imagenes/' (que contiene la carpeta CheXpert-v1.0)
        # img_path = os.path.join(self.img_dir, img_path_partial)

        # Alternativa si img_dir es la raíz de CheXpert-v1.0 (contiene train/, valid/):
        img_path = os.path.join(self.img_dir, '/'.join(img_path_partial.split('/')[1:]))

        # --- Carga y Transformación de la Imagen ---
        try:
            # Cargar imagen (usualmente en escala de grises 'L' para CheXpert)
            image = Image.open(img_path).convert('L')
            # O convertir a 'RGB' si tu red espera 3 canales
            # image = Image.open(img_path).convert('RGB')
        except FileNotFoundError:
            print(f"ADVERTENCIA: Imagen no encontrada en {img_path} para índice {idx}. Retornando None.")
            # Es crucial manejar esto en tu DataLoader con un `collate_fn` si retornas None
            return None, None
        except Exception as e:
            print(f"ADVERTENCIA: Error cargando imagen {img_path}: {e}. Retornando None.")
            return None, None

        # Aplicar transformaciones si existen
        if self.transform:
            image = self.transform(image)

        # --- Codificación de Etiquetas a 20 bits ---
        label_vector_20_list = [] # Usamos una lista para construir el vector

        # Obtener los valores crudos (-1, 0, 1, NaN) para las 5 clases de esta fila
        raw_labels = row[self.classes].values

        for raw_label in raw_labels:
            # Convertir el valor crudo al vector de 4 bits correspondiente
            if pd.isna(raw_label): # Chequeo explícito de NaN
                label_vector_20_list.extend(self.notmentioned_vec)
            elif raw_label == 1.0:
                label_vector_20_list.extend(self.present_vec)
            elif raw_label == 0.0:
                label_vector_20_list.extend(self.absent_vec)
            elif raw_label == -1.0:
                label_vector_20_list.extend(self.uncertain_vec)
            else:
                # Manejar cualquier valor inesperado (opcionalmente tratar como no mencionado)
                print(f"ADVERTENCIA: {img_path_partial} Valor de etiqueta inesperado {raw_label} en índice {idx}. Tratando como No Mencionado.")
                label_vector_20_list.extend(self.notmentioned_vec)

        # Verificar que la longitud sea correcta (5 patologías * 4 bits = 20)
        if len(label_vector_20_list) != 20:
            print(f"ERROR: El vector de etiquetas final tiene longitud {len(label_vector_20_list)} en lugar de 20 para índice {idx}.")
            # Decide cómo manejar este error, aquí retornamos None
            return None, None

        # Convertir la lista final a un FloatTensor de PyTorch
        label_tensor = torch.tensor(label_vector_20_list, dtype=torch.float32)

        return image, label_tensor

# --- Ejemplo de Uso (Fuera de la clase) ---
if __name__ == '__main__':
    # Rutas y parámetros de ejemplo (¡ajústalos!)
    csv_file = '/workspace/WORKS/DATA/CheXpert-v1.0-small/train.csv'
    image_directory = '/workspace/WORKS/DATA/CheXpert-v1.0-small/' # Ruta que contiene train/, valid/
    pathology_classes = ['Atelectasis', 'Cardiomegaly', 'Consolidation', 'Edema', 'Pleural Effusion'] # Tus 5 clases

    # Define tus transformaciones (ejemplo simple)
    from torchvision import transforms
    img_size = 320
    # Asegúrate que coincida con lo que espera tu modelo (canales, normalización)
    transformations = transforms.Compose([
        transforms.Resize((img_size, img_size)),
        transforms.ToTensor(), # Convierte a [C, H, W] y escala a [0, 1]
        # transforms.Normalize(mean=[0.5], std=[0.5]) # Ejemplo para 1 canal
        # O si conviertes a RGB:
        # transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])

    # Crear instancia del dataset
    dataset = ChexpertDataset20Bit(
        csv_path=csv_file,
        img_dir=image_directory,
        classes_list=pathology_classes,
        transform=transformations
    )

    # Probar obtener un elemento
    if len(dataset) > 0:
        # Función collate simple para manejar Nones si __getitem__ los retorna
        def collate_fn_skip_none(batch):
            batch = list(filter(lambda x: x is not None and x[0] is not None, batch))
            if not batch:
                return None, None # O devuelve tensores vacíos si prefieres
            return torch.utils.data.dataloader.default_collate(batch)

        # Crear DataLoader
        dataloader = torch.utils.data.DataLoader(dataset, batch_size=4, shuffle=True, collate_fn=collate_fn_skip_none)

        # Obtener un batch
        try:
             # Iterar sobre el dataloader para obtener batches
             data_iter = iter(dataloader)
             first_batch_images, first_batch_labels = next(data_iter)

             if first_batch_images is not None:
                  print("Forma del batch de imágenes:", first_batch_images.shape)
                  print("Forma del batch de etiquetas:", first_batch_labels.shape)
                  print("Ejemplo de primera etiqueta (20 bits):", first_batch_labels[0])
             else:
                  print("El primer batch estaba vacío o contenía errores.")

        except StopIteration:
             print("El DataLoader está vacío.")

    else:
        print("El dataset está vacío, verifica las rutas.")